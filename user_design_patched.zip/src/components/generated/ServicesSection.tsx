import React from 'react';
import { motion } from 'framer-motion';
import { Camera, Heart, Users, Briefcase, Baby, Star } from 'lucide-react';
const services = [{
  id: 'weddings',
  icon: Heart,
  title: 'Wedding Photography',
  description: 'Capturing your special day with artistic vision and attention to every precious moment',
  price: 'Starting at $2,500'
}, {
  id: 'portraits',
  icon: Camera,
  title: 'Portrait Sessions',
  description: 'Professional headshots and personal portraits that showcase your unique personality',
  price: 'Starting at $350'
}, {
  id: 'events',
  icon: Users,
  title: 'Event Photography',
  description: 'Corporate events, parties, and celebrations documented with professional excellence',
  price: 'Starting at $800'
}, {
  id: 'commercial',
  icon: Briefcase,
  title: 'Commercial Work',
  description: 'Brand photography, product shoots, and marketing materials for your business',
  price: 'Starting at $1,200'
}, {
  id: 'family',
  icon: Baby,
  title: 'Family & Maternity',
  description: 'Beautiful family portraits and maternity sessions in natural, comfortable settings',
  price: 'Starting at $450'
}, {
  id: 'fine-art',
  icon: Star,
  title: 'Fine Art Prints',
  description: 'Limited edition prints and custom artwork for your home or office spaces',
  price: 'Starting at $125'
}] as any[];

// @component: ServicesSection
export const ServicesSection = () => {
  // @return
  return <section className="py-24 bg-white" aria-labelledby="services-heading">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.header initial={{
        opacity: 0,
        y: 24
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} viewport={{
        once: true
      }} className="mb-12">
          <h2 id="services-heading" className="text-3xl md:text-4xl font-extrabold tracking-tight text-gray-900 mb-3"><span>Why clients choose me</span></h2>
          <p className="text-gray-600 md:text-lg max-w-2xl"><span>Premium craft, seamless process, and images that feel effortless.</span></p>
        </motion.header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
          const IconComponent = service.icon;
          return <motion.article key={service.id} initial={{
            opacity: 0,
            y: 24
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: index * 0.15
          }} viewport={{
            once: true
          }} className="p-8 rounded-3xl bg-neutral-50 border border-black/5 shadow-[0_2px_0_0_rgba(0,0,0,0.04)] hover:shadow-[0_6px_30px_rgba(0,0,0,0.06)] transition-shadow">
                <div className="flex items-center space-x-3 mb-5">
                  <div className="w-10 h-10 rounded-2xl bg-white border border-black/5 flex items-center justify-center">
                    <IconComponent className="h-5 w-5 text-gray-900" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900"><span>{service.title}</span></h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed"><span>{service.description}</span></p>
                <p className="text-gray-900 font-semibold"><span>{service.price}</span></p>
              </motion.article>;
        })}
        </div>
      </div>
    </section>;
};