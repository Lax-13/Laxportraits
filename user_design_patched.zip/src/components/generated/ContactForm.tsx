import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, Instagram, Facebook, Twitter } from 'lucide-react';
const testimonials = [{
  id: 'test1',
  name: 'Sarah & James',
  text: 'Elena captured our wedding perfectly. Every photo tells our story beautifully.',
  rating: 5
}, {
  id: 'test2',
  name: 'Michael Chen',
  text: 'Professional headshots that exceeded expectations. Highly recommended!',
  rating: 5
}, {
  id: 'test3',
  name: 'The Johnson Family',
  text: 'Amazing family portraits. Elena made everyone feel comfortable and natural.',
  rating: 5
}] as any[];

// @component: ContactForm
export const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsSubmitting(false);
    setFormData({
      name: '',
      email: '',
      phone: '',
      service: '',
      message: ''
    });
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // @return
  return <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <motion.div initial={{
          opacity: 0,
          x: -30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }} viewport={{
          once: true
        }}>
            <div className="mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6"><span>About Elena</span></h2>
              <div className="prose prose-lg text-gray-600">
                <p><span>With over 8 years of experience in professional photography, I specialize in capturing authentic emotions and creating timeless memories. My passion lies in telling stories through imagery, whether it's your wedding day, family milestones, or professional portraits.</span></p>
                <p><span>Based in San Francisco, I bring a unique blend of artistic vision and technical expertise to every session, ensuring that each photograph reflects the genuine beauty and personality of my subjects.</span></p>
              </div>
            </div>
            
            <div className="mb-12">
              <h3 className="text-2xl font-bold text-gray-900 mb-6"><span>What Clients Say</span></h3>
              <div className="space-y-6">
                {testimonials.map((testimonial, index) => <motion.div key={testimonial.id} initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} transition={{
                duration: 0.6,
                delay: index * 0.1
              }} viewport={{
                once: true
              }} className="p-6 bg-white rounded-xl shadow-md">
                    <div className="flex mb-2">{Array.from({
                    length: testimonial.rating
                  }).map((_, i) => <span key={i} className="text-yellow-400">★</span>)}</div>
                    <p className="text-gray-700 mb-3"><span>"{testimonial.text}"</span></p>
                    <p className="font-semibold text-gray-900"><span>- {testimonial.name}</span></p>
                  </motion.div>)}
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3"><Mail className="h-5 w-5 text-gray-600" /><span className="text-gray-700">elena@rodriguezphotography.com</span></div>
              <div className="flex items-center space-x-3"><Phone className="h-5 w-5 text-gray-600" /><span className="text-gray-700">(415) 555-0123</span></div>
              <div className="flex items-center space-x-3"><MapPin className="h-5 w-5 text-gray-600" /><span className="text-gray-700">San Francisco Bay Area</span></div>
              <div className="flex items-center space-x-4 pt-4">
                <Instagram className="h-6 w-6 text-gray-600 hover:text-gray-900 cursor-pointer transition-colors duration-300" />
                <Facebook className="h-6 w-6 text-gray-600 hover:text-gray-900 cursor-pointer transition-colors duration-300" />
                <Twitter className="h-6 w-6 text-gray-600 hover:text-gray-900 cursor-pointer transition-colors duration-300" />
              </div>
            </div>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          x: 30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }} viewport={{
          once: true
        }} className="bg-white p-8 rounded-2xl shadow-xl">
            <h3 className="text-3xl font-bold text-gray-900 mb-8"><span>Let's Work Together</span></h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <input type="text" name="name" placeholder="Your Name" value={formData.name} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all duration-300" required />
                <input type="email" name="email" placeholder="Email Address" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all duration-300" required />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <input type="tel" name="phone" placeholder="Phone Number" value={formData.phone} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all duration-300" />
                <select name="service" value={formData.service} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all duration-300" required>
                  <option value="">Select Service</option>
                  <option value="wedding">Wedding Photography</option>
                  <option value="portrait">Portrait Session</option>
                  <option value="event">Event Photography</option>
                  <option value="commercial">Commercial Work</option>
                  <option value="family">Family & Maternity</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <textarea name="message" placeholder="Tell me about your vision..." rows={6} value={formData.message} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all duration-300 resize-none" required></textarea>
              <button type="submit" disabled={isSubmitting} className="w-full py-4 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors duration-300 font-semibold text-lg flex items-center justify-center space-x-2 disabled:opacity-70">
                {isSubmitting ? <span>Sending...</span> : <><Send className="h-5 w-5" /><span>Send Message</span></>}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>;
};